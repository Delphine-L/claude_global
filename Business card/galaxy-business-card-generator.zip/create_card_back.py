#!/usr/bin/env python3
"""
Generate Galaxy Project Business Card - Back Side with contact info
"""

from PIL import Image, ImageDraw, ImageFont
import qrcode

# Card dimensions (3.5" x 2" at 300 DPI)
CARD_WIDTH = 1050
CARD_HEIGHT = 600

# Colors
WHITE = (255, 255, 255)
GRAY_DARK = (88, 89, 91)  # Galaxy brand gray
GRAY_LIGHT = (150, 150, 150)
GOLD = (206, 184, 36)  # Galaxy brand gold


def generate_qr(url, size=100):
    """Generate a QR code image"""
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=10,
        border=0,
    )
    qr.add_data(url)
    qr.make(fit=True)
    
    qr_img = qr.make_image(fill_color=GRAY_DARK, back_color='white')
    qr_img = qr_img.resize((size, size), Image.Resampling.LANCZOS)
    
    return qr_img


def load_and_resize_logo(path, max_size):
    """Load a logo and resize it maintaining aspect ratio"""
    logo = Image.open(path)
    
    if logo.mode != 'RGBA':
        logo = logo.convert('RGBA')
    
    ratio = min(max_size / logo.width, max_size / logo.height)
    new_size = (int(logo.width * ratio), int(logo.height * ratio))
    
    logo = logo.resize(new_size, Image.Resampling.LANCZOS)
    return logo


def paste_with_transparency(base, overlay, position):
    """Paste an image with transparency support"""
    if overlay.mode == 'RGBA':
        temp = Image.new('RGBA', base.size, (255, 255, 255, 255))
        temp.paste(base.convert('RGBA'), (0, 0))
        temp.paste(overlay, position, overlay)
        return temp.convert('RGB')
    else:
        base.paste(overlay, position)
        return base


def create_business_card_back():
    """Main function to create the business card back"""
    
    # Create white background
    img = Image.new('RGB', (CARD_WIDTH, CARD_HEIGHT), WHITE)
    draw = ImageDraw.Draw(img)
    
    # =====================
    # FONT PATHS
    # =====================
    exo_bold = "fonts/static/Exo-Bold.ttf"
    exo_semibold = "fonts/static/Exo-SemiBold.ttf"
    exo_medium = "fonts/static/Exo-Medium.ttf"
    exo_regular = "fonts/static/Exo-Regular.ttf"
    exo_light = "fonts/static/Exo-Light.ttf"
    try:
        name_font = ImageFont.truetype(exo_bold, 42)
        title_font = ImageFont.truetype(exo_medium, 26)
        info_font = ImageFont.truetype(exo_light, 24)
        contact_font = ImageFont.truetype(exo_regular, 26)
        cite_header_font = ImageFont.truetype(exo_semibold, 24)
        cite_font = ImageFont.truetype(exo_regular, 20)
    except:
        name_font = ImageFont.load_default()
        title_font = ImageFont.load_default()
        info_font = ImageFont.load_default()
        contact_font = ImageFont.load_default()
        cite_header_font = ImageFont.load_default()
        cite_font = ImageFont.load_default()
    
    # =====================
    # LOGO PATH
    # =====================
    print("Loading logo...")
    galaxy_logo = load_and_resize_logo("logos/transparent_400x400.png", 140)
    
    # =====================
    # PERSONAL INFO - CUSTOMIZE THESE
    # =====================
    NAME = "Delphine Larivière, Ph.D."
    JOB_TITLE = "Research Assistant Professor"
    PRONOUNS = "She/Her"
    LAB_TEAM = "Nekrutenko Lab, Galaxy Team"
    UNIVERSITY = "Penn State University"
    RESEARCH_FOCUS = "Bioinformatics workflows"
    GITHUB_HANDLE = "Delphine-L"
    EMAIL = "delphine.lariviere@galaxyproject.org"
    ORCID_URL = "https://orcid.org/0000-0001-6421-3484"
    # =====================
    
    # Layout
    left_margin = 50
    top_margin = 45
    
    # Logo in top right corner
    logo_x = CARD_WIDTH - galaxy_logo.width - 50
    logo_y = top_margin
    img = paste_with_transparency(img, galaxy_logo, (logo_x, logo_y))
    draw = ImageDraw.Draw(img)
    
    # Name
    y = top_margin
    draw.text((left_margin, y), NAME, fill=GRAY_DARK, font=name_font)
    
    # Gold accent line under name
    y += 58
    draw.rectangle([left_margin, y, left_margin + 280, y + 4], fill=GOLD)
    
    # Job title
    y += 20
    draw.text((left_margin, y), JOB_TITLE, fill=GRAY_DARK, font=title_font)
    
    # Pronouns
    y += 32
    draw.text((left_margin, y), f"Pronouns: {PRONOUNS}", fill=GRAY_LIGHT, font=title_font)
    pronouns_end_y = y + 30  # approximate end of pronouns section
    
    # Footer - Affiliation and Research focus
    footer_y = CARD_HEIGHT - 75
    draw.text((left_margin, footer_y), f"{LAB_TEAM}  •  {UNIVERSITY}", fill=GRAY_DARK, font=title_font)
    footer_y += 28
    draw.text((left_margin, footer_y), f"Research focus: {RESEARCH_FOCUS}", fill=GRAY_LIGHT, font=info_font)
    
    # Calculate vertical center for contact info and QR code
    footer_start_y = CARD_HEIGHT - 75
    available_space = footer_start_y - pronouns_end_y
    content_height = 60 + 150  # GitHub + Email lines (~60px) + QR with label (~150px)
    center_y = pronouns_end_y + (available_space - content_height) // 2
    
    # Contact info - centered vertically
    contact_y = center_y + 20
    draw.text((left_margin, contact_y), f"GitHub: {GITHUB_HANDLE}", fill=GRAY_DARK, font=contact_font)
    # Underline "GitHub"
    github_bbox = draw.textbbox((left_margin, contact_y), "GitHub", font=contact_font)
    draw.line([(github_bbox[0], github_bbox[3] + 2), (github_bbox[2], github_bbox[3] + 2)], fill=GRAY_DARK, width=1)
    
    contact_y += 35
    draw.text((left_margin, contact_y), f"Email: {EMAIL}", fill=GRAY_DARK, font=contact_font)
    # Underline "Email"
    email_bbox = draw.textbbox((left_margin, contact_y), "Email", font=contact_font)
    draw.line([(email_bbox[0], email_bbox[3] + 2), (email_bbox[2], email_bbox[3] + 2)], fill=GRAY_DARK, width=1)
    
    # ORCID QR code - bottom right, aligned with logo
    orcid_qr = generate_qr(ORCID_URL, 120)
    qr_x = CARD_WIDTH - 120 - 50  # Same x alignment as logo
    qr_y = CARD_HEIGHT - 120 - 50  # Bottom with margin
    
    # Light border around QR
    draw.rectangle([qr_x - 6, qr_y - 6, qr_x + 120 + 6, qr_y + 120 + 6], outline=(210, 210, 210), width=2)
    img.paste(orcid_qr, (qr_x, qr_y))
    
    # ORCID label - rotated 90 degrees, to the right of QR
    orcid_label_font = ImageFont.truetype("fonts/static/Exo-Medium.ttf", 16)
    label = "ORCID"
    
    # Create temporary image for rotated text
    label_bbox = draw.textbbox((0, 0), label, font=orcid_label_font)
    label_width = label_bbox[2] - label_bbox[0]
    label_height = label_bbox[3] - label_bbox[1]
    
    # Create image for text, rotate it
    txt_img = Image.new('RGBA', (label_width + 10, label_height + 10), (255, 255, 255, 0))
    txt_draw = ImageDraw.Draw(txt_img)
    txt_draw.text((5, 5), label, fill=GRAY_DARK, font=orcid_label_font)
    txt_img = txt_img.rotate(-90, expand=True)
    
    # Paste rotated text to the right of QR code
    label_x = qr_x + 120 + 8
    label_y = qr_y + (120 - txt_img.height) // 2
    img = img.convert('RGBA')
    img.paste(txt_img, (label_x, label_y), txt_img)
    img = img.convert('RGB')
    draw = ImageDraw.Draw(img)
    
    # Border
    draw.rectangle([0, 0, CARD_WIDTH - 1, CARD_HEIGHT - 1], outline=(230, 230, 230), width=1)
    
    # Save
    output_path = "/home/claude/galaxy-business-card-back.png"
    img.save(output_path, "PNG", quality=100)
    print(f"Saved to {output_path}")
    
    return output_path


if __name__ == "__main__":
    create_business_card_back()
