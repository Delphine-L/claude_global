#!/usr/bin/env python3
"""
Generate Galaxy Project Business Card with maximum size QR codes
"""

from PIL import Image, ImageDraw, ImageFont
import qrcode

# Card dimensions (3.5" x 2" at 300 DPI)
CARD_WIDTH = 1050
CARD_HEIGHT = 600

# Colors
WHITE = (255, 255, 255)
GRAY_DARK = (88, 89, 91)  # Galaxy brand gray
GRAY_LIGHT = (150, 150, 150)
GOLD = (206, 184, 36)  # Galaxy brand gold


def generate_qr(url, size=100):
    """Generate a QR code image"""
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=10,
        border=0,
    )
    qr.add_data(url)
    qr.make(fit=True)
    
    qr_img = qr.make_image(fill_color=GRAY_DARK, back_color='white')
    qr_img = qr_img.resize((size, size), Image.Resampling.LANCZOS)
    
    return qr_img


def load_and_resize_logo(path, max_size):
    """Load a logo and resize it maintaining aspect ratio"""
    logo = Image.open(path)
    
    if logo.mode != 'RGBA':
        logo = logo.convert('RGBA')
    
    ratio = min(max_size / logo.width, max_size / logo.height)
    new_size = (int(logo.width * ratio), int(logo.height * ratio))
    
    logo = logo.resize(new_size, Image.Resampling.LANCZOS)
    return logo


def paste_with_transparency(base, overlay, position):
    """Paste an image with transparency support"""
    if overlay.mode == 'RGBA':
        temp = Image.new('RGBA', base.size, (255, 255, 255, 255))
        temp.paste(base.convert('RGBA'), (0, 0))
        temp.paste(overlay, position, overlay)
        return temp.convert('RGB')
    else:
        base.paste(overlay, position)
        return base


def create_business_card():
    """Main function to create the business card"""
    
    # Create white background
    img = Image.new('RGB', (CARD_WIDTH, CARD_HEIGHT), WHITE)
    draw = ImageDraw.Draw(img)
    
    # =====================
    # FONT PATHS
    # =====================
    exo_bold = "fonts/static/Exo-Bold.ttf"
    exo_semibold = "fonts/static/Exo-SemiBold.ttf"
    exo_medium = "fonts/static/Exo-Medium.ttf"
    exo_regular = "fonts/static/Exo-Regular.ttf"
    exo_light = "fonts/static/Exo-Light.ttf"
    try:
        title_font = ImageFont.truetype(exo_bold, 52)
        subtitle_font = ImageFont.truetype(exo_light, 20)
        label_font = ImageFont.truetype(exo_semibold, 23)
        footer_font = ImageFont.truetype(exo_regular, 21)
    except:
        title_font = ImageFont.load_default()
        subtitle_font = ImageFont.load_default()
        label_font = ImageFont.load_default()
        footer_font = ImageFont.load_default()
    
    # =====================
    # LOGO PATHS
    # =====================
    print("Loading logos...")
    galaxy_logo = load_and_resize_logo("logos/transparent_400x400.png", 130)
    iwc_logo = load_and_resize_logo("logos/iwc_logo.png", 77)
    gtn_logo = load_and_resize_logo("logos/GTNStarBars300.png", 77)
    hub_logo = load_and_resize_logo("logos/transparent_400x400.png", 77)
    
    # Header section (from v2)
    print("Drawing header...")
    header_y = 30
    
    # Galaxy logo (left side)
    logo_x = 50
    img = paste_with_transparency(img, galaxy_logo, (logo_x, header_y))
    draw = ImageDraw.Draw(img)
    
    # Title text next to logo
    text_x = logo_x + galaxy_logo.width + 25
    draw.text((text_x, header_y + 10), "GALAXY", fill=GRAY_DARK, font=title_font)
    draw.text((text_x, header_y + 68), "Data intensive science for everyone", 
              fill=GRAY_LIGHT, font=subtitle_font)
    
    # Subtle gold accent line
    draw.rectangle([text_x, header_y + 98, text_x + 220, header_y + 102], fill=GOLD)
    
    # QR codes section - MAXIMIZED
    print("Generating QR codes...")
    
    # Calculate QR size at 80% of maximum
    # Header ends around y=140, footer area is ~50px
    header_height = 160
    footer_height = 60
    label_height = 45
    logo_height = 90  # Space for logo under QR
    
    available_height = CARD_HEIGHT - header_height - footer_height - label_height - logo_height
    available_width_per_qr = (CARD_WIDTH - 100) // 3 - 20
    
    max_qr_size = min(available_height, available_width_per_qr)
    qr_size = int(max_qr_size * 0.64)  # 64% of max (was 80%, reduced by 20%)
    
    print(f"QR size: {qr_size}px (64% of {max_qr_size}px)")
    
    # Center vertically between header and footer
    footer_start = CARD_HEIGHT - footer_height
    available_vertical = footer_start - header_height
    qr_block_height = qr_size + logo_height + label_height  # QR + logo + label
    qr_y = header_height + (available_vertical - qr_block_height) // 2
    
    qr_data = [
        ("https://iwc.galaxyproject.org/", "Workflows", iwc_logo),
        ("https://galaxyproject.org", "Galaxy Project", hub_logo),
        ("https://training.galaxyproject.org", "Training Material", gtn_logo),
    ]
    
    # Calculate spacing for 3 QR codes
    total_qr_width = 3 * qr_size
    total_gap = CARD_WIDTH - 100 - total_qr_width  # 100 for margins (50 each side)
    gap = total_gap // 4  # gaps on sides and between
    
    start_x = 50 + gap
    
    for i, (url, label, small_logo) in enumerate(qr_data):
        x = start_x + i * (qr_size + gap)
        
        # QR code
        qr_img = generate_qr(url, qr_size)
        
        # Light border
        border_padding = 6
        draw.rectangle(
            [x - border_padding, qr_y - border_padding, 
             x + qr_size + border_padding, qr_y + qr_size + border_padding],
            outline=(210, 210, 210), width=2
        )
        
        # Paste QR code
        img.paste(qr_img, (x, qr_y))
        
        # Logo centered under QR code
        logo_x = x + (qr_size - small_logo.width) // 2
        logo_y = qr_y + qr_size + 12
        img = paste_with_transparency(img, small_logo, (logo_x, logo_y))
        draw = ImageDraw.Draw(img)
        
        # Label below logo (only if label is not empty)
        # Use fixed y position for horizontal alignment (based on logo_height constant)
        if label:
            label_bbox = draw.textbbox((0, 0), label, font=label_font)
            label_width = label_bbox[2] - label_bbox[0]
            label_x = x + (qr_size - label_width) // 2
            label_y = qr_y + qr_size + 12 + 77 + 5  # Fixed position: qr bottom + padding + max logo height + spacing
            draw.text((label_x, label_y), label, fill=GRAY_DARK, font=label_font)
    
    # Footer
    print("Drawing footer...")
    footer_y = CARD_HEIGHT - 45
    
    draw.text((50, footer_y), "galaxyproject.org", fill=GRAY_LIGHT, font=footer_font)
    
    # Line
    draw.line([(270, footer_y + 12), (CARD_WIDTH - 340, footer_y + 12)], fill=(220, 220, 220), width=1)
    
    # Motto
    motto = "Open Source  •  Open Science"
    motto_bbox = draw.textbbox((0, 0), motto, font=footer_font)
    motto_width = motto_bbox[2] - motto_bbox[0]
    draw.text((CARD_WIDTH - motto_width - 50, footer_y), motto, fill=GRAY_LIGHT, font=footer_font)
    
    # Border
    draw.rectangle([0, 0, CARD_WIDTH - 1, CARD_HEIGHT - 1], outline=(230, 230, 230), width=1)
    
    # Save
    output_path = "/home/claude/galaxy-business-card.png"
    img.save(output_path, "PNG", quality=100)
    print(f"Saved to {output_path}")
    
    return output_path


if __name__ == "__main__":
    create_business_card()
